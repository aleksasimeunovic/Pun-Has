package com.example.demo.controller;

import com.example.demo.service.KupacService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class KupacRestController {
    @Autowired
    private KupacService kupacService;
}
