package com.example.demo.model;

import javax.persistence.*;

@Entity
public class Artikal {
    public Artikal(){}

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public enum Tip {Jelo,Pice}
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "Tip",nullable = false)
    private Tip Tip;

    @Column(name = "Name",nullable = false)
    private String name;

    @Column(name = "Cena",nullable = false)
    private double Cena;


    @Column(name = "Kolicina", nullable = false)
    private double Kolicina;

    @Column(name = "Opis")
    private String Opis;

    public Artikal(Artikal.Tip tip, String naziv, double cena, double kolicina) {
        Tip = tip;
        this.name = naziv;
        Cena = cena;
        Kolicina = kolicina;
    }

    public Artikal(Artikal.Tip tip, String naziv, double cena) {
        Tip = tip;
        this.name = naziv;
        Cena = cena;
    }

    public Artikal.Tip getTip() {
        return Tip;
    }

    public void setTip(Artikal.Tip tip) {
        Tip = tip;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getCena() {
        return Cena;
    }

    public void setCena(double cena) {
        Cena = cena;
    }

    public double getKolicina() {
        return Kolicina;
    }

    public void setKolicina(double kolicina) {
        Kolicina = kolicina;
    }

    public String getOpis() {
        return Opis;
    }

    public void setOpis(String opis) {
        Opis = opis;
    }

    public Long getId() {
        return id;
    }
}