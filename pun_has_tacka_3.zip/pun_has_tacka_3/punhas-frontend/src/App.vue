<template>
<div id="app">

  <!-- NAVBAR -->
  <nav class="navbar navbar-light bg-light navbar-expand-lg">
    <a class="navbar-brand" href="#">
    <img src="@/assets/logo.png" height="40" class="d-inline-block align-top" alt=""/>
    </a>
    <!-- button koji se pojavljuje tokom screen resizinga-->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
     <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">

    <li class="nav-item">
        <a class="nav-link" href="#"><router-link to="/">Home</router-link></a>
    </li>

    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Nalozi
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#"><router-link to="/register">Register</router-link></a>
          <a class="dropdown-item" href="#"><router-link to="/login">Login</router-link></a>
        </div>
    </li>

    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Admin
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#"><router-link to="/dodajRestoran">+ Restoran</router-link></a>
          <a class="dropdown-item" href="#"><router-link to="/dodajMenadzera">+ Menadzer</router-link></a>
          <a class="dropdown-item" href="#"><router-link to="/dodajDostavljaca">+ Dostavljac</router-link></a>
          <a class="dropdown-item" href="#"><router-link to="/pregledajKorisnike">Pregledaj korisnike</router-link></a>
          <a class="dropdown-item" href="#"><router-link to="/pregledajRestorane">Pregledaj restorane</router-link></a>
        </div>
    </li>

    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Menadzer
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#"><router-link to="/upravljanjeRestoranima">Upravljanje restoranima</router-link></a>
          <a class="dropdown-item" href="#"><router-link to="/dodajArtikal">+ Artikal</router-link></a>
          <a class="dropdown-item" href="#"><router-link to="/pregledajArtikle">Artikli</router-link></a>
          <a class="dropdown-item" href="#"><router-link to="/pregledajPorudzbine">Pregledaj porudzbine</router-link></a>
        </div>
    </li>

    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Kupac
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#"><router-link to="/restoraniKupac">Restorani</router-link></a>
          <a class="dropdown-item" href="#"><router-link to="/mojaKorpa">Moja korpa</router-link></a>
          <a class="dropdown-item" href="#"><router-link to="/mojePorudzbine">Moje porudzbine</router-link></a>
        </div>
    </li>

    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Dostavljac
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#"><router-link to="/aktivnePorudzbine">Aktivne porudzbine</router-link></a>
        </div>
    </li>
    </ul>
  </div>
  </nav>
</div>
<div class="container">
    <router-view/>
    <!-- tu router dinamcki ubaci screen-->
</div>
  <footer class="text-center text-lg-start navbar fixed-bottom" style="background-color: #262626;">
  <!-- Copyright -->
  <div class="text-center p-3 text-light" style="margin-left: 2vw;">
    © 2022 Copyright Pun Has Company 
  </div>
</footer>
</template>

<script>
  export default {
    name: "App", 
    components: {},
  };
</script>
<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #d72323;
    }
    text-decoration:none;
  }
  a:link {
   color: #d72323 !important;
  }

  a:hover {
   color: #f24a26;
  }

  .dropdown-item:hover{
    color:#f2f2f2  !important;
    transition: 0.5s;
  }

  .nav-item:hover{
    color:#f2f2f2  !important;
    background-color:#efefef  !important;
    transition: 0.5s;
  }


}
</style>
