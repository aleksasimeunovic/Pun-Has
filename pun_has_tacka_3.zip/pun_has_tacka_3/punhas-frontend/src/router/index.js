import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import Register from '../views/RegisterView.vue'
import PregledajKorisnikeView from '../views/PregledajKorisnikeView.vue'
import KorisnikView from '../views/KorisnikView.vue'



const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/register', 
    name: 'RegisterView',
    component: () => import(/* webpackChunkName: "register" */ '../views/RegisterView.vue')
  },
  {
    path: '/login', 
    name: 'LoginView',
    component: () => import(/* webpackChunkName: "login" */ '../views/LoginView.vue')
  },
  {
    path: '/dodajRestoran', 
    name: 'DodajRestoranView',
    component: () => import(/* webpackChunkName: "dodajRestoran" */ '../views/DodajRestoranView.vue')
  },
  {
    path: '/dodajMenadzera', 
    name: 'DodajMenadzeraView',
    component: () => import(/* webpackChunkName: "dodajMenadzera" */ '../views/DodajMenadzeraView.vue')
  },
  {
    path: '/dodajDostavljaca', 
    name: 'DodajDostavljacaView',
    component: () => import(/* webpackChunkName: "dodajDostavljaca" */ '../views/DodajDostavljacaView.vue')
  },
  {
    path: '/pregledajKorisnike', 
    name: 'PregledajKorisnikeView',
    component: PregledajKorisnikeView
  },
  {
    path: '/korisnik', 
    name: 'KorisnikView',
    component: KorisnikView
  },
  {
    path: '/pregledajRestorane', 
    name: 'PregledajRestoraneView',
    component: () => import(/* webpackChunkName: "pregledajRestorane" */ '../views/PregledajRestoraneView.vue')
  },
  {
    path: '/upravljanjeRestoranima', 
    name: 'UpravljanjeRestoranimaView',
    component: () => import(/* webpackChunkName: "upravljanjeRestoranima" */ '../views/UpravljanjeRestoranimaView.vue')
  },
  {
    path: '/dodajArtikal', 
    name: 'DodajArtikalView',
    component: () => import(/* webpackChunkName: "dodajArtikal" */ '../views/DodajArtikalView.vue')
  },
  {
    path: '/pregledajArtikle', 
    name: 'PregledajArtikleView',
    component: () => import(/* webpackChunkName: "pregledajArtikleView" */ '../views/PregledajArtikleView.vue')
  },
  {
    path: '/restoraniKupac', 
    name: 'KupacRestoraniView',
    component: () => import(/* webpackChunkName: "KupacRestoraniView" */ '../views/KupacRestoraniView.vue')
  },
  {
    path: '/mojaKorpa', 
    name: 'KupacMojaKorpaView',
    component: () => import(/* webpackChunkName: "pregledajArtikleView" */ '../views/KupacMojaKorpaView.vue')
  },
  {
    path: '/mojePorudzbine', 
    name: 'KupacMojePorudzbineView',
    component: () => import(/* webpackChunkName: "KupacMojePorudzbineView" */ '../views/KupacMojePorudzbineView.vue')
  },
  {
    path: '/artikalZaIzmenu:id', 
    name: 'ArtikalZaIzmenu',
    component: () => import(/* webpackChunkName: "artikalZaIzmenu" */ '../views/ArtikalZaIzmenu.vue')
  },
  {
    path: '/dodajPorudzbinu', 
    name: 'PorudzbinaView',
    component: () => import(/* webpackChunkName: "dodajPorudzbinu" */ '../views/PorudzbinaView.vue')
  },
  {
    path: '/artikliRestorana/:naziv-:id', 
    name: 'ArtikliRestorana',
    component: () => import(/* webpackChunkName: "artikliRestorana" */ '../views/ArtikliRestorana.vue')
  },
  {
    path: '/pregledajPorudzbine', 
    name: 'PregledajPorudzbineView',
    component: () => import(/* webpackChunkName: "dodajPorudzbinu" */ '../views/PregledajPorudzbineView.vue')
  },
  {
    path: '/aktivnePorudzbine', 
    name: 'DostavljacAktivnePorudzbineView',
    component: () => import(/* webpackChunkName: "dodajPorudzbinu" */ '../views/DostavljacAktivnePorudzbineView.vue')
  },
  {
    path: '/mojiBodovi', 
    name: 'MojiBodoviView',
    component: () => import(/* webpackChunkName: "dodajPorudzbinu" */ '../views/MojiBodoviView.vue')
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
