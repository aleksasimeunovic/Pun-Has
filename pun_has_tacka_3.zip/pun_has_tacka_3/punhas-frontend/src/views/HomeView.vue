<template>
  <div class="home">
      Homepage
  </div>
</template>

<script>

export default {
  name: 'HomeView',
  components: {
  }
}
</script>

