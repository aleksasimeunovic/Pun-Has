<template>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h3 class="pt-3">Uloguj se</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-3"></div>
            
            <div class="col-6">
                <form>
                    <div class="form-group">
                        <label for="username">Korisnicko ime</label>
                        <input type="text" class="form-control" v-model="korisnik.username">
                    </div> 

                     <div class="form-group">
                        <label for="password">Lozinka</label>
                        <input type="password" class="form-control" v-model="korisnik.password">
                    </div>
                        <br>
                    <button type="button" class="btn btn-primary" v-on:click="logujSe()"> Loguj se </button>
                    <button type="reset" class="btn btn-danger"> Resetuj </button>
                </form>
            </div>
            
            <div class="col-3"></div>
            
        </div>
    </div>
</template>

<script>
import axios from "axios"; 
export default {
    name: "LoginView", 
    data: function() {
        return { 
            korisnik: {
                username: "", 
                password: ""
            }, 
            
        };
    },
    methods: {
        logujSe: function() {
            axios
                .post("http://localhost:8081/api/login", this.korisnik, {
                    withCredentials: true
                })
                .then(res => {
                    console.log(res); 
                    this.$router.push("/login"); 
                    alert("Dobrodosli!"); 
                })
                .catch(error => {
                    console.log(error.response); 
                    alert("Neuspesno logovanje"); 
                });
        }
    }
};
</script>
<style scoped>

</style>