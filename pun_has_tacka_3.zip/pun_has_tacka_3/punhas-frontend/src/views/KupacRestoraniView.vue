<template>
  <div id="sviRestorani">
    <h1>Restorani</h1>
    <br /><br />
    <div class="container-restorani">
      <table id="restorani">
        <tr>
          <th>Naziv</th>
          <th>Tip</th>
          <th>gSirina</th>
          <th>gVisina</th>
          <th>Adresa</th>
          <th>Otvoren</th>
          <th>Radnja</th>
        </tr>
        <tr v-for="restoran in restorani" :key="restoran.id">
          <td>{{ restoran.naziv }}</td>
          <td>{{ restoran.tip }}</td>
          <td>{{ restoran.gSirina }}</td>
          <td>{{ restoran.gVisina }}</td>
          <td>{{ restoran.adresa }}</td>
          <td v-if="restoran.radi">Radi</td>
          <td v-else>Ne radi</td>
          <td>
            <router-link :to="{name: 'ArtikliRestorana', params:{id: restoran.id, naziv: restoran.naziv}}">
            <button class="btn btn-warning">
              Artikli
            </button>
            </router-link>
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "PregledajRestoraneView",
  data: function () {
    return {
      restorani: [],
    };
  },
  mounted: function () {
    axios
      .get("http://localhost:8081/api/pregledRestorana" , {withCredentials:true}) 
      .then((res) => {
        this.restorani = res.data
      })
      .catch((err) =>{
        console.log(err)
      })
  },
  prikaziArtikle: function () {
      this.$router.push("/restoran?id=" + this.restoran.id);
    },
};
</script>

<style>
h1 {
  color: #4caf50;
}

h3 {
  color: #4caf50;
}

.container-restorani {
  display: flex;
  justify-content: center;
}

#restorani th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4caf50;
  color: white;
}

#restorani td,
#restorani th {
  border: 1px solid #ddd;
  padding: 8px;
}

#restorani tr:nth-child(even) {
  background-color: #f2f2f2;
}

#restorani tr:hover {
  background-color: #ddd;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
}

.title {
  color: grey;
  font-size: 18px;
}
</style>

