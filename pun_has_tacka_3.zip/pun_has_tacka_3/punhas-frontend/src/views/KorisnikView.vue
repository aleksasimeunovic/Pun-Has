<template>
<div>
    <h2 style="text-align:center">Profil korisnika</h2>
    <div class="card">
        <img alt="Slika" src="../assets/user.png"/>
        <h1> {{ korisnik.name }} </h1>
        <h1> {{ korisnik.lastName }} </h1>
        <p class="title">{{korisnik.uloga}}</p>
        <br>
    </div>
</div>
</template>
<script>
import axios from "axios";
export default {
    name: 'KorisnikView',
    data: function() {
        return {
            korisnik: {},
        }
    },
    mounted: function() {
        axios
            .get("http://localhost:8081/api/admin/pregled/" + this.$route.query.id, {withCredentials:true})
            .then((res) => {
                this.korisnik = res.data
            })
            .catch((err) => {
                console.log(err)
            })
    }
}
</script>
