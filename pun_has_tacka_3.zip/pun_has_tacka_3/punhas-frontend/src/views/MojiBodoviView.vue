<template>
<div>
    <h1> Broj vasih bodova je: {{ korisnik.brojSkupljenihBod }} </h1>
</div>
</template>
<script>
import axios from "axios";
export default {
    name: 'MojiBodoviView',
    data: function() {
        return {
            korisnik: {},
        }
    },
    mounted: function() {
        axios
            .get("http://localhost:8081/api/admin/pregled/" + this.$route.query.id, {withCredentials:true})
            .then((res) => {
                this.korisnik = res.data
            })
            .catch((err) => {
                console.log(err)
            })
    }
}
</script>
