<template>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h3 class="pt-3">Dodaj restoran</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-3"></div>
            
            <div class="col-6 ">
                <form>
                    <div class="form-group">
                        <label for="name">Ime restorana</label>
                        <input type="text" class="form-control" v-model="restoran.naziv">
                    </div> 

                    
                    <div class="form-group">
                        <label for="address">Adresa</label>
                        <input type="text" class="form-control" v-model="restoran.adresa" >
                    </div>

                    
                    <div class="form-group">
                        <label for="type">Tip restorana</label>
                        <input type="text" class="form-control" v-model="restoran.tip">
                    </div>

                     <div class="form-group">
                        <label for="gSirina">Lokacija: gSirina</label>
                        <input type="text" class="form-control" v-model="restoran.gSirina">
                    </div>

                     <div class="form-group">
                        <label for="gVisina">Lokacija: gVisina</label>
                        <input type="text" class="form-control" v-model="restoran.gVisina">
                    </div>

                    <div class="form-group">
                        <label for="username-menadzera">username Menadzera</label>
                        <input type="text" class="form-control" v-model="restoran.menadzer">
                    </div>
                    <br>
                    <button type="button" class="btn btn-primary" v-on:click="dodajRestoran()"> Dodaj </button>
                    <button type="reset" class="btn btn-danger"> Resetuj </button>
                </form>
            </div>
            
            <div class="col-3"></div>
            
        </div>
    </div>
</template>

<script>

import axios from "axios"; 
export default {
 name: "DodajRestoranView", 
    data: function() {
        return { 
            restoran: {
                naziv: "", 
                adresa: "",
                tip: "", 
                gSirina: "",
                gVisina: "",
                menadzer: ""
            }, 
            
        };
    },
    methods: {
        dodajRestoran: function() {
            axios
                .post("http://localhost:8081/api/admin/createRestoran", this.restoran, {
                    withCredentials: true
                })
                .then(res => {
                    console.log(res); 
                    this.$router.push("/dodajRestoran"); 
                    alert("Uspesno dodat restoran"); 
                })
                .catch(error => {
                    console.log(error.response); 
                    alert("Neuspesno dodat restoran"); 
                });
        }
    }
};
</script>
