<template>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h3 class="pt-3">Dodaj dostavljaca</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-3"></div>
            
            <div class="col-6 ">
                <form>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" v-model="dostavljac.username">
                    </div> 

                    
                    <div class="form-group">
                        <label for="password">Sifra</label>
                        <input type="password" class="form-control" v-model="dostavljac.password" >
                    </div>

                    
                    <div class="form-group">
                        <label for="name">Ime</label>
                        <input type="text" class="form-control" v-model="dostavljac.name">
                    </div>

                     <div class="form-group">
                        <label for="surname">Prezime</label>
                        <input type="text" class="form-control" v-model="dostavljac.lastName">
                    </div>
                    
                    <div>
                        <br>
                        <select v-model="dostavljac.pol" class="form-select" aria-label="Default select example">
                            <option value="" selected disabled> Odaberite pol</option>
                            <option value="0">Musko</option>
                            <option value="1">Zensko</option>
                        </select>
                    </div>

                    <br>
                    <button type="button" class="btn btn-primary" v-on:click="dodajDostavljaca()"> Dodaj </button>
                    <button type="reset" class="btn btn-danger"> Resetuj </button>
                </form>
            </div>
            
            <div class="col-3"></div>
            
        </div>
    </div>
</template>

<script>

import axios from "axios"; 
export default {
 name: "DodajDostavljacaView", 
    data: function() {
        return { 
            dostavljac: {
                username: "", 
                password: "",
                name: "", 
                lastName: "",
                pol: ""
            }, 
            
        };
    },
    methods: {
        dodajDostavljaca: function() {
            axios
                .post("http://localhost:8081/api/register/dostavljac", this.dostavljac, {
                    withCredentials: true
                })
                .then(res => {
                    console.log(res); 
                    this.$router.push("/dodajDostavljaca"); 
                    alert("Uspesno dodat dostavljac"); 
                })
                .catch(error => {
                    console.log(error.response); 
                    alert("Neuspesno dodat dostavljac"); 
                });
        }
    }
};
</script>
