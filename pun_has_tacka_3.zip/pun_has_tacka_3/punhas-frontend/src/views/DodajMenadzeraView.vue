<template>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h3 class="pt-3">Dodaj menadzera</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-3"></div>
            
            <div class="col-6 ">
                <form>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" v-model="menadzer.username">
                    </div> 

                    
                    <div class="form-group">
                        <label for="password">Sifra</label>
                        <input type="password" class="form-control" v-model="menadzer.password" >
                    </div>

                    
                    <div class="form-group">
                        <label for="name">Ime</label>
                        <input type="text" class="form-control" v-model="menadzer.name">
                    </div>

                     <div class="form-group">
                        <label for="surname">Prezime</label>
                        <input type="text" class="form-control" v-model="menadzer.lastName">
                    </div>
                    
                    <div>
                        <br>
                        <select v-model="menadzer.pol" class="form-select" aria-label="Default select example">
                            <option value="" selected disabled> Odaberite pol</option>
                            <option value="0">Musko</option>
                            <option value="1">Zensko</option>
                        </select>
                    </div>

                    <br>
                    <button type="button" class="btn btn-primary" v-on:click="dodajMenadzera()"> Dodaj </button>
                    <button type="reset" class="btn btn-danger"> Resetuj </button>
                </form>
            </div>
            
            <div class="col-3"></div>
            
        </div>
    </div>
</template>

<script>

import axios from "axios"; 
export default {
 name: "DodajMenadzeraView", 
    data: function() {
        return { 
            menadzer: {
                username: "", 
                password: "",
                name: "", 
                lastName: "",
                pol: ""
            }, 
            
        };
    },
    methods: {
        dodajMenadzera: function() {
            axios
                .post("http://localhost:8081/api/register/menadzer", this.menadzer, {
                    withCredentials: true
                })
                .then(res => {
                    console.log(res); 
                    this.$router.push("/dodajMenadzera"); 
                    alert("Uspesno dodat menadzer"); 
                })
                .catch(error => {
                    console.log(error.response); 
                    alert("Neuspesno dodat menadzer"); 
                });
        }
    }
};
</script>
