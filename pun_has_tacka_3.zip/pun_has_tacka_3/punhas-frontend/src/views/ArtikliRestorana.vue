<template>
  <div id="sviArtikli">
    <h1>Artikli</h1>
    <br /><br />
    <div class="container-artikli">
      <table id="artikli">
        <tr>
          <th>ID</th>
          <th>Naziv</th>
          <th>Cena</th>
          <th>Tip</th>
        </tr>
        <tr v-for="artikal in artikli" :key="artikal.id">
          <td>{{ artikal.id }}</td>
          <td>{{ artikal.name }}</td>
          <td>{{ artikal.cena }}</td>
          <td>{{ artikal.tip }}</td>
        </tr>
      </table>
    </div>
    <br><br><br>
    <div class="col-3"></div>
    <h3>Ime restorana: {{ this.$route.params.naziv }}</h3>
    <br><br><br>
    <div class="col-6 text-center">
                <form>
                    <div class="form-group">
                        <label for="username"> Ime restorana </label>
                        <input type="text"
                          class="form-control"
                          v-model="narudzbina.restoran">
                    </div> 

                    
                    <div class="form-group">
                        <label for="name"> ID Artikla </label>
                        <input type="number" class="form-control" v-model="narudzbina.id" >
                    </div>

                    <div class="form-group">
                        <label for="name"> Kolicina </label>
                        <input type="number" class="form-control" v-model="narudzbina.kolicina" >
                    </div>
                        <br>
                    <button type="button" class="btn btn-primary" v-on:click="dodajUKorpu()"> Dodaj u korpu </button>
                    <button type="reset" class="btn btn-danger"> Resetuj </button>
                    <router-link :to="{name: 'KupacMojaKorpaView', params:{}}">
                      <button class="btn btn-success">
                        Moja Korpa
                      </button>
                    </router-link>
                </form>
            </div>
    <div class="col-3"></div>
            
    </div>

   
</template>

<script>
import axios from "axios";
export default {
  name: "ArtikliRestorana",
  data: function () {
    return {
      artikli: [],
      artikal: {
                naziv: "", 
                noviNaziv: "",
                cena: "",
                tip: ""
            },

      narudzbina: {
                restoran: this.$route.params.naziv, 
                id: "",
                kolicina: ""
            }

          
    };
  },
  mounted: function () {
    console.log('The id is: ' + this.$route.params.id);
    console.log('The name is: ' + this.$route.params.naziv);
    axios
      .get("http://localhost:8081/api/kupac/prikazArtikala/" +this.$route.params.id  , {withCredentials:true}) //.get("http://localhost:8081/api/menadzer/pregledArtikala" , {withCredentials:true})
      .then((res) => {
        this.artikli = res.data
      })
      .catch((err) =>{
        console.log(err)
      })
    
  },
  computed: {
    imeRestorana(){
      return this.$route.params.naziv;
    }
  },
  methods: {
    obrisiArtikal: function(id) {
            axios
                .delete("http://localhost:8081/api/menadzer/izbrisiArtikal/"+id, {
                    withCredentials: true
                })
                .then(res => {
                    console.log(res); 
                    window.location.reload();
                })
                .catch(error => {
                    console.log(error.response); 
                    alert("Uspesno brisanje");
                    window.location.reload(); 
                });
    },
    izmeniArtikal: function(id) {
            axios
                .put("http://localhost:8081/api/menadzer/izmeniArtikal", this.artikal, {
                    withCredentials: true
                })
                .then(res => {
                    console.log(res); 
                    alert("Izmenjen artikal!"); 
                    window.location.reload(); 

                })
                .catch(error => {
                    console.log(error.response); 
                    alert("Neuspesno izmenjen artikal"); 
                    window.location.reload(); 
                });
    },
    dodajUKorpu: function() {
          axios
              .post("http://localhost:8081/api/kupac/dodajukorpu", this.narudzbina, {
                  withCredentials: true
              })
              .then(res => {
                  console.log(res); 
                  alert("Uspesno dodavanje"); 
              })
              .catch(error => {
                  console.log(error.response); 
                  alert("Neuspesno dodavanje"); 
              });
      }

  },

};
</script>

<style>
h1 {
  color: #4caf50;
}

h3 {
  color: #4caf50;
}

.container-artikli {
  display: flex;
  justify-content: center;
}

#artikli th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4caf50;
  color: white;
}

#artikli td,
#artikli th {
  border: 1px solid #ddd;
  padding: 8px;
}

#artikli tr:nth-child(even) {
  background-color: #f2f2f2;
}

#artikli   tr:hover {
  background-color: #ddd;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
}

.title {
  color: grey;
  font-size: 18px;
}
</style>

