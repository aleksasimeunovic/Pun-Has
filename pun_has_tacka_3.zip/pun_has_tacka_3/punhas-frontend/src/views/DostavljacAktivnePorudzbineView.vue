<template>
  <div id="svePorudzbine">
    <h1>Porudzbine za dostavu</h1>
    <br /><br />
    <div class="container-porudzbine">
      <table id="porudzbine">
        <tr>
          <th>UUID</th>
          <th>Artikli u porudzbini i broj tih artikala</th>
          <th>UCena</th>
          <th>Status</th>
          <th>Radnja</th>
        </tr>
        <tr v-for="porudzbina in porudzbine" :key="porudzbina.UUID">
          <td>{{ porudzbina.uuid }}</td>
          <td>{{ porudzbina.listaArtikalaUPorudzbini}}</td>
          <td>{{ porudzbina.ucena }}</td>
          <td>{{ porudzbina.status }}</td>
          <td>
            <button class="btn btn-primary" v-on:click="dostavi(porudzbina.uuid)">
              Dostavi
            </button>
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "DostavljacAktivnePorudzbineView",
  data: function () {
    return {
      porudzbine: [],
    };
  },
  mounted: function () {
    axios
      .get("http://localhost:8081/api/dostavljac/porudzbine", {withCredentials:true}) 
      .then((res) => {
        this.porudzbine = res.data
      })
      .catch((err) =>{
        console.log(err)
      })
  },
  methods: {
    dostavi : function(uuid){
      axios
              .put("http://localhost:8081/api/dostavljac/preuzmi/"+uuid, this.narudzbina, {
                  withCredentials: true
              })
              .then(res => {
                  console.log(res); 
                  alert("Uspesno dostavljeno"); 
                    window.location.reload(); 
              })
              .catch(error => {
                  console.log(error.response); 
                  alert("Neuspesno dostavljeno"); 
                    window.location.reload(); 
              });
    },
  },

};
</script>

<style>
h1 {
  color: #4caf50;
}

h3 {
  color: #4caf50;
}

.container-porudzbine {
  display: flex;
  justify-content: center;
}

#porudzbine th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4caf50;
  color: white;
}

#porudzbine td,
#porudzbine th {
  border: 1px solid #ddd;
  padding: 8px;
}

#porudzbine tr:nth-child(even) {
  background-color: #f2f2f2;
}

#porudzbine tr:hover {
  background-color: #ddd;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
}

.title {
  color: grey;
  font-size: 18px;
}
</style>

