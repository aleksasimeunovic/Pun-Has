<template>
  <div id="sviKorisnici">
    <h1>Korisnici</h1>
    <br /><br />
    <div class="container-korisnici">
      <table id="korisnici">
        <tr>
          <th>Username</th>
          <th>Sifra</th>
          <th>Ime</th>
          <th>Prezime</th>
          <th>Pol</th>
        </tr>
        <tr v-for="korisnik in korisnici" :key="korisnik.id">
          <td>{{ korisnik.username }}</td>
          <td>{{ korisnik.password }}</td>
          <td>{{ korisnik.name }}</td>
          <td>{{ korisnik.lastName }}</td>
          <td>{{ korisnik.pol }}</td>
        </tr>
      </table>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "PregledajKorisnikeView",
  data: function () {
    return {
      korisnici: [],
    };
  },
  mounted: function () {
    axios
      .get("http://localhost:8081/api/admin/pregled" , {withCredentials:true}) 
      .then((res) => {
        this.korisnici = res.data
      })
      .catch((err) =>{
        console.log(err)
      })
  },
  methods: {
    seeMore: function (korisnik) {
      this.$router.push("/korisnik?id=" + korisnik.id);
    },
  },
};
</script>

<style>
h1 {
  color: #4caf50;
}

h3 {
  color: #4caf50;
}

.container-korisnici {
  display: flex;
  justify-content: center;
}

#korisnici th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4caf50;
  color: white;
}

#korisnici td,
#korisnici th {
  border: 1px solid #ddd;
  padding: 8px;
}

#korisnici tr:nth-child(even) {
  background-color: #f2f2f2;
}

#korisnici tr:hover {
  background-color: #ddd;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
}

.title {
  color: grey;
  font-size: 18px;
}
</style>

