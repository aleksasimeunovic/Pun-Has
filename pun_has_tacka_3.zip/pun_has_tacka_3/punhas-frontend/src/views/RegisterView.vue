<template>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h3 class="pt-3">Registruj se</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-3"></div>
            
            <div class="col-6">
                <form>
                    <div class="form-group">
                        <label for="username">Korisnicko ime</label>
                        <input type="text" class="form-control" v-model="korisnik.username">
                    </div> 

                    
                    <div class="form-group">
                        <label for="name">Ime </label>
                        <input type="text" class="form-control" v-model="korisnik.name" >
                    </div>

                    
                    <div class="form-group">
                        <label for="surname">Prezime</label>
                        <input type="text" class="form-control" v-model="korisnik.lastName">
                    </div>

                     <div class="form-group">
                        <label for="password">Lozinka</label>
                        <input type="password" class="form-control" v-model="korisnik.password">
                    </div>

                    <div>
                        <br>
                        <select v-model="korisnik.pol" class="form-select" aria-label="Default select example">
                            <option value="" selected disabled> Odaberite pol</option>
                            <option value="0">Musko</option>
                            <option value="1">Zensko</option>
                        </select>
                    </div>
                        <br>
                    <button type="button" class="btn btn-primary" v-on:click="registrujSe()"> Registruj se </button>
                    <button type="reset" class="btn btn-danger"> Resetuj </button>
                </form>
            </div>
            
            <div class="col-3"></div>
            
        </div>
    </div>
</template>

<script>
import axios from "axios"; 
export default {
    name: "RegisterView", 
    data: function() {
        return { 
            korisnik: {
                username: "", 
                password: "",
                name: "", 
                lastName: "",
                pol: ""
            }, 
            
        };
    },
    methods: {
        registrujSe: function() {
            axios
                .post("http://localhost:8081/api/kupac/register", this.korisnik, {
                    withCredentials: true
                })
                .then(res => {
                    console.log(res); 
                    this.$router.push("/register"); 
                    alert("Uspesno registrovanje"); 
                })
                .catch(error => {
                    console.log(error.response); 
                    alert("Neuspesno registrovanje"); 
                });
        }
    }
};
</script>
<style scoped>

</style>