<template>
  <div id="sviArtikli">
    <h1>Artikli</h1>
    <br /><br />
    <div class="container-artikli">
      <table id="artikli">
        <tr>
          <th>Naziv</th>
          <th>Cena</th>
          <th>Tip</th>
          <th>Radnja</th>
        </tr>
        <tr v-for="artikal in artikli" :key="artikal.id">
          <td>{{ artikal.name }}</td>
          <td>{{ artikal.cena }}</td>
          <td>{{ artikal.tip }}</td>
          <td>
            <button class="btn btn-danger" v-on:click="obrisiArtikal(artikal.id)">
              Obrisi
            </button>
          </td>
        </tr>
      </table>
    </div>

    <div class="container-forma-artikli">
       <div class="row">
            <div class="col-12 text-center">
                <h3 class="pt-3"> Izmeni zeljeni artikal </h3>
            </div>
        </div>
        <div class="row">
            <div class="col-3"></div>
            
            <div class="col-6">
                <form>
                    <div class="form-group">
                        <label for="username">Ime artikla koji zelis da izmenis</label>
                        <input type="text" class="form-control" v-model="this.artikal.naziv">
                    </div> 

                    <div class="form-group">
                        <label for="username">Novo ime artikla</label>
                        <input type="text" class="form-control" v-model="this.artikal.noviNaziv">
                    </div> 

                    <div class="form-group">
                        <label for="username">Cena artikla</label>
                        <input type="text" class="form-control" v-model="this.artikal.cena">
                    </div> 

                    <div>
                        <br>
                        <select v-model="artikal.tip" class="form-select" aria-label="Default select example">
                            <option value="" selected disabled> Novi tip artikla</option>
                            <option value="1">Pice</option>
                            <option value="0">Jelo</option>
                        </select>
                    </div>
                    <br><br>
                    <button type="button" class="btn btn-primary" v-on:click="izmeniArtikal(artikal.id)"> Izmeni artikal </button>
                    <button type="reset" class="btn btn-danger"> Resetuj </button>
                </form>
            </div>
            
            <div class="col-3"></div>
            
        </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "PregledajArtikleView",
  data: function () {
    return {
      artikli: [],
     /* art: {
                naziv: artikal.naziv, 
                noviNaziv: "",
                cena: "", 
                tip: ""
      }, */
      artikal: {
                naziv: "", 
                noviNaziv: "",
                cena: "",
                tip: ""
            }
    };
  },
  mounted: function () {
    axios
      .get("http://localhost:8081/api/menadzer/pregledArtikala" , {withCredentials:true}) 
      .then((res) => {
        this.artikli = res.data
      })
      .catch((err) =>{
        console.log(err)
      })
  },
  methods: {
    obrisiArtikal: function(id) {
            axios
                .delete("http://localhost:8081/api/menadzer/izbrisiArtikal/"+id, {
                    withCredentials: true
                })
                .then(res => {
                    console.log(res); 
                    window.location.reload();
                })
                .catch(error => {
                    console.log(error.response); 
                    alert("Uspesno brisanje");
                    window.location.reload(); 
                });
    },
    izmeniArtikal: function(id) {
            axios
                .put("http://localhost:8081/api/menadzer/izmeniArtikal", this.artikal, {
                    withCredentials: true
                })
                .then(res => {
                    console.log(res); 
                    alert("Izmenjen artikal!"); 
                    window.location.reload(); 

                })
                .catch(error => {
                    console.log(error.response); 
                    alert("Neuspesno izmenjen artikal"); 
                    window.location.reload(); 
                });
        }
    /*izmeniArtikal: function() {
          axios 
              .get("http://localhost:8081/api/menadzer/pregledArtikala", {
                withCredentials: true
              })
              .then(res => {
                    console.log(res); 
                    this.$router.push("/artikalZaIzmenu"); 
                    window.location.reload();
                })
                .catch(error => {
                    console.log(error.response); 
                    alert("Uspesna izmena");
                    window.location.reload(); 
                });          
    },*/

  },

};
</script>

<style>
h1 {
  color: #4caf50;
}

h3 {
  color: #4caf50;
}

.container-artikli {
  display: flex;
  justify-content: center;
}

#artikli th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4caf50;
  color: white;
}

#artikli td,
#artikli th {
  border: 1px solid #ddd;
  padding: 8px;
}

#artikli tr:nth-child(even) {
  background-color: #f2f2f2;
}

#artikli   tr:hover {
  background-color: #ddd;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
}

.title {
  color: grey;
  font-size: 18px;
}
</style>

