<template>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h3 class="pt-3">Dodaj artikal</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-3"></div>
            
            <div class="col-6 ">
                <form>
                    <div class="form-group">
                        <label for="name">Naziv</label>
                        <input type="text" class="form-control" v-model="artikal.naziv">
                    </div> 

                    
                    <div class="form-group">
                        <label for="price">Cena</label>
                        <input type="text" class="form-control" v-model="artikal.cena" >
                    </div>

                    
                    <div>
                        <br>
                        <select v-model="artikal.tip" class="form-select" aria-label="Default select example">
                            <option value="" selected disabled> Odaberite tip</option>
                            <option value="1">Pice</option>
                            <option value="0">Jelo</option>
                        </select>
                    </div>

                    <br>
                    <button type="button" class="btn btn-primary" v-on:click="dodajArtikal()"> Dodaj </button>
                    <button type="reset" class="btn btn-danger"> Resetuj </button>
                </form>
            </div>
            
            <div class="col-3"></div>
            
        </div>
    </div>
</template>

<script>

import axios from "axios"; 
export default {
 name: "DodajArtikalView", 
    data: function() {
        return { 
            artikal: {
                naziv: "", 
                cena: "",
                tip: ""
            }, 
            
        };
    },
    methods: {
        dodajArtikal: function() {
            axios
                .post("http://localhost:8081/api/menadzer/dodavanjeArtikla", this.artikal, {
                    withCredentials: true
                })
                .then(res => {
                    console.log(res); 
                    this.$router.push("/dodajArtikal"); 
                    alert("Uspesno dodat artikal"); 
                })
                .catch(error => {
                    console.log(error.response); 
                    alert("Neuspesno dodat artikal"); 
                });
        }
    }
};
</script>
